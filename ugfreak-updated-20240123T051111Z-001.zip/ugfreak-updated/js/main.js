
if( $('.new_arrival_slider, .related_product_slider').length){
    $('.new_arrival_slider, .related_product_slider').slick({
        dots: false,
        arrows: true,
        infinite: true,
        speed: 300,
        slidesToShow: 5,
        slidesToScroll: 1,
        centerPadding: 20,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 4,
                    slidesToScroll: 4
                }
            },
            {
                breakpoint: 1100,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 900,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 400,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
}

// SPECIAL ORDER
if( $('.special_order_slider').length){
    $('.special_order_slider').slick({
        dots: false,
        arrows: true,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        centerPadding: 20,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 1100,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 900,
                settings: {
                    slidesToShow: 3,
                    slidesToScroll: 3
                }
            },
            {
                breakpoint: 767,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 400,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
}



// POPULAR SLIDER
if( $('.popular_slider_02').length){
    $('.popular_slider_02').slick({
        rows: 2,
        dots: true,
        arrows: true,
        infinite: true,
        speed: 300,
        slidesToShow: 3,
        slidesToScroll: 1,
        centerPadding: 20,
        responsive: [
            {
                breakpoint: 1200,
                settings: {
                    slidesToShow: 2,
                    slidesToScroll: 2
                }
            },
            {
                breakpoint: 800,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            },
            {
                breakpoint: 400,
                settings: {
                    slidesToShow: 1,
                    slidesToScroll: 1
                }
            }
        ]
    });
}


$(document).ready(function(){
    
    $('.login_btn').click(function(){
        if($('.login_popup').is(':visible') == true){
          $('.login_popup').slideUp(200);
          $('body').removeClass('show_overlay');
        } else{
          $('.login_popup').slideDown(200);
          $('body').addClass('show_overlay');
        }
    });
    
    $(document).on('mouseup', function(e){
        var container = $(".login_popup");
        if(!container.is(e.target) && container.has(e.target).length === 0){
            container.hide();
            $('body').removeClass('show_overlay');
        }    
    });

    $(document).on('click', '.decrease_btn',function(e){
        var decreament_val = $(this).siblings('input').val();
        decreament_val = decreament_val - 1;
        $(this).siblings('input').val(decreament_val);
     });
     $(document).on('click', '.increase_btn', function(){
      var increament_val = $(this).siblings('input').val();
      $(this).siblings('input').val(+increament_val + 1);
     });

     
    $('.menu_bar').click(function(){
        if($(this).siblings('ul').is(":visible") == true){
            $(this).siblings('ul').slideUp(300);
            $(this).removeClass('active');

        }else{
            $(this).siblings('ul').slideDown(300);
            $(this).addClass('active');
        }
    });
});
